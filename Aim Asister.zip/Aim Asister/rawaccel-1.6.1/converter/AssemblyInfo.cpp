#include <rawaccel-version.h>

using namespace System;
using namespace System::Reflection;
using namespace System::Runtime::CompilerServices;
using namespace System::Runtime::InteropServices;
using namespace System::Security::Permissions;

[assembly:AssemblyVersion(RA_VER_STRING)]

[assembly:ComVisible(false)] ;
[assembly:CLSCompliantAttribute(true)] ;
